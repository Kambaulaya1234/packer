After packer build starts check your cloud portal under. It will create a VM in few mins. 
For AWS it will create an EC2 instance
Also check the AMI option. It will show a new AMI created. 


## Deleting AMI in AWS
#### To delete the AMI
- Deregister the AMI
- Delete the Snapshot (deregistering the AMI doesn't delete the snapshot automatically. It needs to be done separately)
