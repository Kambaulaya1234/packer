[Click here](https://github.com/e2eSolutionArchitect/hcp-packer-image-builder-pipeline/tree/main/ado-pipelines) for more pipelines in action
